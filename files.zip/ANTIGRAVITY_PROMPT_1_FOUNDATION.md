# ANTIGRAVITY FOUNDATION PROMPT
# Copy and paste this entire block into Antigravity as your first message.
# This sets up the entire project foundation in one session.

---

Read AGENTS.md, GEMINI.md, and DESIGN.md in full before doing anything else.
Confirm you have read all three files by listing the 4 font families and the 5 CSS color
categories from DESIGN.md. Then proceed with the following tasks in order.

---

## TASK 1: Clean up the project

Delete these files/folders from the project root (they are default Next.js scaffolding
that we no longer need):
- public/next.svg
- public/vercel.svg  
- src/app/fonts/ (entire folder)
- Replace README.md content with: "# Sigma Oilfield & Industrial Supply DMCC\nNext.js 15 + Tailwind 4 + GSAP + Framer Motion"

Do NOT delete or modify:
- next.config.ts
- package.json
- tsconfig.json
- eslint.config.mjs
- postcss.config.mjs
- .gitignore

---

## TASK 2: Install new packages

Run these installs:
```bash
npm install gsap lenis page-flip splitting
```

After install, confirm each appears in package.json dependencies.

---

## TASK 3: Create the directory structure

Create these empty directories (with .gitkeep files so they commit):
```
src/components/ui/
src/components/layout/
src/components/sections/
src/components/animations/
src/components/three/
src/providers/
src/hooks/
src/lib/
src/types/
public/textures/
public/videos/
public/logos/
```

---

## TASK 4: Create globals.css with the full Carbon Precision design token system

Replace the existing src/app/globals.css entirely with the following. This is the
entire design token system — do not omit any variable:

```css
@import "tailwindcss";

/* ============================================================
   SIGMA CARBON PRECISION — Design Token System
   Version 2.0
   ============================================================ */

:root {
  /* Carbon Black Series */
  --sigma-carbon-black: #0a0f18;
  --sigma-carbon-900:   #111827;
  --sigma-carbon-800:   #1a2744;
  --sigma-carbon-700:   #243352;
  --sigma-carbon-600:   #334566;

  /* Signal Red Series */
  --sigma-red-600:  #b91c1c;
  --sigma-red-500:  #dc2626;
  --sigma-red-400:  #ef4444;
  --sigma-red-300:  #f87171;
  --sigma-coral:    #ff6b5a;

  /* Tech Cyan */
  --sigma-cyan-500: #06b6d4;
  --sigma-cyan-400: #22d3ee;

  /* Desert Sand */
  --sigma-sand-500: #d4a574;
  --sigma-sand-300: #e8d4b8;
  --sigma-ochre:    #c9840a;

  /* Neutrals */
  --sigma-white:        #ffffff;
  --sigma-neutral-50:   #f9fafb;
  --sigma-neutral-100:  #f3f4f6;
  --sigma-neutral-200:  #e5e7eb;
  --sigma-neutral-400:  #9ca3af;
  --sigma-neutral-600:  #4b5563;
  --sigma-neutral-900:  #111827;

  /* Semantic */
  --sigma-success:   #22c55e;
  --sigma-warning:   #f59e0b;
  --sigma-error:     #ef4444;
  --sigma-in-stock:  #4ade80;
  --sigma-limited:   #fbbf24;
  --sigma-out-stock: #f87171;

  /* Gradients */
  --sigma-gradient-cta:  linear-gradient(135deg, #dc2626 0%, #ff6b5a 100%);
  --sigma-gradient-dark: linear-gradient(180deg, #1a2744 0%, #0a0f18 100%);
  --sigma-gradient-text: linear-gradient(135deg, #1a2744 0%, #dc2626 50%, #ff6b5a 100%);

  /* Patterns */
  --sigma-dotgrid:      radial-gradient(circle, #334566 1px, transparent 1px);
  --sigma-dotgrid-size: 24px 24px;

  /* Typography */
  --font-display:   var(--font-jakarta), sans-serif;
  --font-body:      var(--font-inter), system-ui, sans-serif;
  --font-editorial: var(--font-playfair), Georgia, serif;
  --font-technical: var(--font-mono), 'Courier New', monospace;

  /* Spacing */
  --section-padding-y: clamp(80px, 10vw, 140px);
  --section-padding-x: clamp(24px, 6vw, 96px);

  /* Transitions */
  --transition-fast:    150ms ease;
  --transition-base:    300ms ease;
  --transition-slow:    500ms ease;
  --transition-spring:  500ms cubic-bezier(0.34, 1.56, 0.64, 1);
  --transition-smooth:  300ms cubic-bezier(0.4, 0.0, 0.2, 1);
}

/* ============================================================
   BASE STYLES
   ============================================================ */

*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  scroll-behavior: auto; /* Lenis handles smooth scroll */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  font-family: var(--font-body);
  font-size: 16px;
  line-height: 1.6;
  color: var(--sigma-neutral-900);
  background-color: var(--sigma-white);
  overflow-x: hidden;
}

/* ============================================================
   TYPOGRAPHY UTILITIES
   ============================================================ */

.text-display-xl {
  font-family: var(--font-display);
  font-size: clamp(60px, 9vw, 96px);
  font-weight: 800;
  line-height: 1.0;
  letter-spacing: -0.02em;
  text-transform: uppercase;
}

.text-display-lg {
  font-family: var(--font-display);
  font-size: clamp(48px, 7vw, 72px);
  font-weight: 800;
  line-height: 1.05;
  letter-spacing: -0.02em;
  text-transform: uppercase;
}

.text-display-md {
  font-family: var(--font-display);
  font-size: clamp(32px, 5vw, 56px);
  font-weight: 700;
  line-height: 1.1;
  letter-spacing: -0.01em;
  text-transform: uppercase;
}

.text-editorial {
  font-family: var(--font-editorial);
  font-size: clamp(32px, 5vw, 56px);
  font-weight: 400;
  font-style: italic;
  line-height: 1.15;
}

.text-technical {
  font-family: var(--font-technical);
  font-size: 12px;
  font-weight: 400;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: var(--sigma-neutral-400);
}

/* Section label — "CORPORATE PROFILE" with red line prefix */
.section-label {
  display: flex;
  align-items: center;
  gap: 12px;
  font-family: var(--font-body);
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--sigma-red-500);
}

.section-label::before {
  content: '';
  display: block;
  width: 24px;
  height: 2px;
  background: var(--sigma-red-500);
  flex-shrink: 0;
}

/* Gradient text */
.text-gradient {
  background: var(--sigma-gradient-text);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* ============================================================
   DARK SECTION BASE
   ============================================================ */

.section-dark {
  position: relative;
  background: var(--sigma-gradient-dark);
  overflow: hidden;
}

.section-dark::before {
  content: '';
  position: absolute;
  inset: 0;
  background-image: var(--sigma-dotgrid);
  background-size: var(--sigma-dotgrid-size);
  opacity: 0.25;
  pointer-events: none;
  z-index: 0;
}

.section-dark > * {
  position: relative;
  z-index: 1;
}

/* Film grain — add class .section-grain to any .section-dark */
.section-grain::after {
  content: '';
  position: absolute;
  inset: 0;
  background-image: url('/textures/grain.png');
  background-repeat: repeat;
  opacity: 0.03;
  mix-blend-mode: overlay;
  pointer-events: none;
  z-index: 0;
}

/* ============================================================
   CURSOR SPOTLIGHT (dark sections)
   ============================================================ */

.spotlight-container {
  position: absolute;
  inset: 0;
  background: radial-gradient(
    800px circle at var(--mouse-x, 50%) var(--mouse-y, 50%),
    rgba(220, 38, 38, 0.04),
    transparent 40%
  );
  pointer-events: none;
  z-index: 0;
  transition: background 0.05s ease;
}

/* ============================================================
   PRIMARY CTA — BORDER BEAM
   ============================================================ */

.cta-primary {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 14px 28px;
  background: var(--sigma-gradient-cta);
  border-radius: 100px;
  border: none;
  overflow: hidden;
  font-family: var(--font-body);
  font-size: 14px;
  font-weight: 600;
  letter-spacing: 0.02em;
  color: white;
  cursor: pointer;
  transition: transform var(--transition-fast), box-shadow var(--transition-base);
}

.cta-primary::before {
  content: '';
  position: absolute;
  inset: -2px;
  border-radius: 100px;
  background: conic-gradient(
    from 0deg,
    transparent 0%,
    transparent 30%,
    #dc2626 50%,
    transparent 70%,
    transparent 100%
  );
  animation: beam-rotate 3s linear infinite;
  z-index: -1;
}

.cta-primary::after {
  content: '';
  position: absolute;
  inset: 2px;
  border-radius: 100px;
  background: var(--sigma-gradient-cta);
  z-index: -1;
}

.cta-primary:hover {
  transform: scale(1.02);
  box-shadow: 0 0 40px rgba(220, 38, 38, 0.35);
}

.cta-primary:active {
  transform: scale(0.98);
}

@keyframes beam-rotate {
  from { transform: rotate(0deg); }
  to   { transform: rotate(360deg); }
}

/* ============================================================
   CERTIFICATION BADGE
   ============================================================ */

.cert-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 5px 12px;
  background: var(--sigma-carbon-900);
  color: var(--sigma-cyan-400);
  font-family: var(--font-technical);
  font-size: 11px;
  letter-spacing: 0.08em;
  border-radius: 4px;
  border: 0.5px solid var(--sigma-cyan-400);
}

/* ============================================================
   AVAILABILITY INDICATOR
   ============================================================ */

.availability {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  font-weight: 500;
}

.availability__dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  animation: pulse-dot 2s ease infinite;
}

.availability--in-stock .availability__dot   { background: var(--sigma-in-stock); }
.availability--limited .availability__dot    { background: var(--sigma-limited); }
.availability--on-request .availability__dot { background: var(--sigma-neutral-400); animation: none; }

@keyframes pulse-dot {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%       { opacity: 0.5; transform: scale(1.25); }
}

/* ============================================================
   SKELETON LOADERS
   ============================================================ */

.skeleton {
  background: linear-gradient(
    90deg,
    var(--sigma-neutral-200) 0%,
    var(--sigma-neutral-100) 50%,
    var(--sigma-neutral-200) 100%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s ease-in-out infinite;
  border-radius: 8px;
}

.section-dark .skeleton {
  background: linear-gradient(
    90deg,
    var(--sigma-carbon-700) 0%,
    var(--sigma-carbon-600) 50%,
    var(--sigma-carbon-700) 100%
  );
  background-size: 200% 100%;
}

@keyframes shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

/* ============================================================
   MARQUEE (Infinite client ticker)
   ============================================================ */

.marquee-wrapper {
  overflow: hidden;
  mask-image: linear-gradient(
    90deg,
    transparent 0%,
    white 10%,
    white 90%,
    transparent 100%
  );
}

.marquee-track {
  display: flex;
  align-items: center;
  gap: 64px;
  width: max-content;
  animation: marquee-scroll 25s linear infinite;
}

.marquee-wrapper:hover .marquee-track {
  animation-play-state: paused;
}

@keyframes marquee-scroll {
  from { transform: translateX(0); }
  to   { transform: translateX(-50%); }
}

/* ============================================================
   FOOTER TOP BORDER (animated gradient)
   ============================================================ */

.footer-gradient-border {
  position: relative;
}

.footer-gradient-border::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(
    90deg,
    var(--sigma-red-600),
    var(--sigma-red-500),
    var(--sigma-coral),
    var(--sigma-red-500),
    var(--sigma-red-600)
  );
  background-size: 200% 100%;
  animation: gradient-shift 8s ease infinite;
}

@keyframes gradient-shift {
  0%, 100% { background-position: 0% 50%; }
  50%       { background-position: 100% 50%; }
}

/* ============================================================
   REDUCED MOTION — always respect user preference
   ============================================================ */

@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
  .marquee-track {
    animation: none;
  }
}
```

---

## TASK 5: Create src/types/index.ts

```typescript
// Sigma Oilfield — Shared TypeScript Types

export type StockStatus = 'in-stock' | 'limited' | 'on-request'

export type ProductSector = 
  | 'drilling-heavy'
  | 'wellhead-pressure'
  | 'tubular-casing'
  | 'safety-compliance'
  | 'chemicals-additives'
  | 'instrumentation'

export type Product = {
  id: string
  name: string
  model?: string
  sector: ProductSector
  description: string
  specifications?: Record<string, string>
  images: string[]
  stockStatus: StockStatus
  certifications?: string[]
}

export type Client = {
  id: string
  name: string
  fullName: string
  logo: string
  description?: string
  sector?: string
}

export type Stat = {
  value: number
  suffix: string
  label: string
  duration?: number
}

export type NavLink = {
  label: string
  href: string
}

export type ContactCard = {
  type: 'phone' | 'mobile' | 'email' | 'address'
  label: string
  value: string
  icon: string
  dark?: boolean
}
```

---

## TASK 6: Create src/lib/constants.ts

```typescript
import type { Client, Stat, NavLink, Product } from '@/types'

export const NAV_LINKS: NavLink[] = [
  { label: 'Home',     href: '/' },
  { label: 'Products', href: '/products' },
  { label: 'Clients',  href: '/clients' },
  { label: 'About',    href: '/about' },
  { label: 'Contact',  href: '/contact' },
]

export const SIGMA_CLIENTS: Client[] = [
  { id: 'ongc',  name: 'ONGC',       fullName: 'Oil and Natural Gas Corporation', logo: '/logos/ongc.png',  description: 'India\'s largest oil and gas exploration company.' },
  { id: 'oil-india', name: 'Oil India', fullName: 'Oil India Limited', logo: '/logos/oil-india.png', description: 'A premier national oil company of India.' },
  { id: 'gnrl',  name: 'GNRL',       fullName: 'Gujarat Natural Resources Limited', logo: '/logos/gnrl.png', description: 'Leading natural gas distribution company.' },
  { id: 'sgd',   name: 'SGD',        fullName: 'SGD', logo: '/logos/sgd.png', description: 'Trusted supply chain partner.' },
]

export const SIGMA_STATS: Stat[] = [
  { value: 95,    suffix: '%',  label: 'On-time delivery rate', duration: 2000 },
  { value: 42,    suffix: '+',  label: 'Sectors served',        duration: 1500 },
  { value: 24,    suffix: '/7', label: 'Response availability',  duration: 1000 },
  { value: 21000, suffix: 'm²', label: 'Jebel Ali workshop',    duration: 2500 },
]

export const TICKER_ITEMS: string[] = [
  'ONGC',
  'Oil India Limited',
  'Gujarat Natural Resources',
  'SGD',
  'API Certified',
  'ISO 9001:2015',
  'DMCC Member',
  '42 Sectors',
  '95% Delivery Rate',
  'Jebel Ali · Dubai',
  'Hyderabad · India',
]

export const CERTIFICATIONS = [
  { code: 'API',          label: 'API Certified Standards' },
  { code: 'ISO 9001',     label: 'ISO 9001:2015 Quality Management' },
  { code: 'DMCC',         label: 'DMCC Member' },
  { code: 'MSME',         label: 'MSME Registered India' },
]
```

---

## TASK 7: Create src/app/layout.tsx (replace existing)

Write a complete Next.js 15 root layout that:
1. Loads all 4 fonts (Plus Jakarta Sans, Inter, Playfair Display, JetBrains Mono) via next/font/google
2. Applies font CSS variables to the html element
3. Sets proper metadata (title, description, og tags) for Sigma Oilfield
4. Imports globals.css
5. Wraps children in LenisProvider (create a stub if it doesn't exist yet)
6. Has correct viewport meta

---

## TASK 8: Create stub providers

Create `src/providers/LenisProvider.tsx`:
- 'use client' directive
- Imports Lenis from 'lenis'
- Initializes Lenis in useEffect with lerp: 0.1, duration: 1.2
- Runs raf loop
- Provides smooth scroll to the app
- Cleans up on unmount

Create `src/providers/index.tsx`:
- Exports a combined `<Providers>` component that wraps LenisProvider (and any future providers)

---

## TASK 9: Create src/hooks/useCursorPosition.ts

A custom hook that:
- Tracks mouse position with mousemove listener
- Returns `{ x, y }` as pixel values
- Updates CSS custom properties `--mouse-x` and `--mouse-y` on the target element
- Cleans up the event listener on unmount
- TypeScript typed, no `any`

---

## VERIFICATION

After completing all tasks, run:
```bash
npm run build
```

The build must pass with zero TypeScript errors and zero ESLint errors.

Then report using the output format from GEMINI.md.
